const sharp = require('sharp');

const convertImage = async (inputPath, outputPath, format) => {
    try {
        await sharp(inputPath)
            .toFormat(format)
            .toFile(outputPath);
    } catch (error) {
        throw new Error(`Error converting image: ${error.message}`);
    }
};

module.exports = { convertImage };
