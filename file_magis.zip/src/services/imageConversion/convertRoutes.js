const { convertImage } = require('./convertService');

const convertRoutes = async (fastify, options) => {
    fastify.post('/convert/:format', async (request, reply) => {
        const { format } = request.params;
        const { file } = request.body;

        if (!file) {
            reply.status(400).send({ error: 'No file uploaded' });
            return;
        }

        const inputPath = `/tmp/input.${file.mimetype.split('/')[1]}`;
        const outputPath = `/tmp/output.${format}`;

        try {
            await convertImage(inputPath, outputPath, format);
            reply.sendFile(outputPath);
        } catch (error) {
            reply.status(500).send({ error: error.message });
        }
    });
};

module.exports = convertRoutes;
