const Fastify = require('fastify');
const app = Fastify();

const imageRoutes = require('./src/routes/imageRoutes');

app.register(imageRoutes, { prefix: '/api' });

app.listen(3000, err => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  console.log('Server listening on http://0.0.0.0:3000');
});
